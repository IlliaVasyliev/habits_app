fixtures = [
    {
        'urlpath': '/habits/create_user',
        'request': {'username': 'user2'},
        'response': {'user_id': 2}
    },
    {
        'urlpath': '/habits/add_user_for_habit',
        'request': {'user_id': 2, 'habit_id': 1},
        'response': {'reg_habit_id': 2}
    },
    {
        'urlpath': '/habits/perform_habit',
        'request': {'user_id': 2, 'habit_id': 1, 'completion_date': '2022-11-01'},
        'response': {'habit_name': 'running', 'total_streak': 1, 'max_streak': 1, 'curr_streak': 1}
    },
    {
        'urlpath': '/habits/perform_habit',
        'request': {'user_id': 2, 'habit_id': 1, 'completion_date': '2022-11-02'},
        'response': {'habit_name': 'running', 'total_streak': 2, 'max_streak': 2, 'curr_streak': 2}
    },
    {
        'urlpath': '/habits/perform_habit',
        'request': {'user_id': 2, 'habit_id': 1, 'completion_date': '2022-11-03'},
        'response': {'habit_name': 'running', 'total_streak': 3, 'max_streak': 3, 'curr_streak': 3}
    },
    {
        'urlpath': '/habits/perform_habit',
        'request': {'user_id': 2, 'habit_id': 1, 'completion_date': '2022-11-04'},
        'response': {'habit_name': 'running', 'total_streak': 4, 'max_streak': 4, 'curr_streak': 4}
    },
    {
        'urlpath': '/habits/get_habit_score',
        'request': {'habit_id': 1},
        'response': {'habit_name': 'running',
                          'score': [
                              {'user_id': 2, 'username': 'user2', 'total_streak': 4},
                              {'user_id': 1, 'username': 'Ilya', 'total_streak': 3}
                          ]
                          }
    }
]
