# Import Libraries
from datetime import datetime
from django import http
from habits import models
# Serializtion Functions


def serialize_mem(membership):
    """Converts membership object into data types understandable by javascript and front-end frameworks.
    :param membership: membership object
    """
    result= {
        "habit_name": membership.habit.habit_name,
        "total_streak": membership.total_streak,
        "max_streak": membership.max_streak,
        "curr_streak": membership.curr_streak,
    }
    return result

def serialize_user(membership):
    """Converts user details into data types understandable by javascript and front-end frameworks
    :param membership: membership object
    """
    result= {
        "user_id": membership.user.id,
        "username": membership.user.username,
        "total_streak": membership.total_streak,
    }
    return result





# Streak Checking Function


def check_streak(latest_date, prev_date, periodicity) -> bool:
    """Returns True if streak is maintained depending on the type of habit (daily or weekly), returns False Otherwise
    :param latest_date: New date to be added for the habit
    :param prev_date: Date when the habit was performed previously
    :param periodicity: Periodicity of the habit, "DAY" for daily or "WEEK" for weekly
    """
    ans = False
    if periodicity == "WEEK":
        ans = (latest_date - prev_date).days < 8
    elif periodicity == "DAY":
        ans= (latest_date - prev_date).days < 2
    return ans

# Object Creation Functions


def create_user(request):
    """Creates a models.User in the database and returns the user id in JSON
    :param request: HttpRequest object
    """
    request_data = request.POST
    user = models.User(username=request_data["username"])
    user.save()
    return http.JsonResponse({'user_id': user.id})


def create_habit(request):
    """Creates a models.Habit in the database and returns the habit id in JSON
    :param request: HttpRequest object
    """
    request_data = request.POST
    habit = models.Habit(
        habit_name=request_data["habit_name"], periodicity=request_data["periodicity"]
    )
    habit.save()
    return http.JsonResponse({"habit_id": habit.id})


def add_user_for_habit(request):
    """Registers user(based on userid) for a habit(based on habit id)
    :param request: HttpRequest object
    """
    request_data = request.POST
    membership = models.UserAndHabitMembership(user=models.User.objects.get(id=request_data["user_id"]), 
        habit=models.Habit.objects.get(id=request_data["habit_id"]))
    membership.save()
    return http.JsonResponse({"reg_habit_id": membership.id})


def perform_habit(request):
    """Creates new action for already defined habit
    :param request: HttpRequest object
    """
    # Get data
    request_data = request.POST
    curr_user = models.User.objects.get(id=request_data["user_id"])
    curr_habit = models.Habit.objects.get(id=request_data["habit_id"])
    completion_date = datetime.strptime(
        request_data["completion_date"], "%Y-%m-%d")
    completion_date = completion_date.date()

    # Get Membership Data
    membership = models.UserAndHabitMembership.objects.get(
        user=curr_user, habit=curr_habit
    )

    # Get models.User models.Habit logs
    last_log = models.Logs.objects.filter(
        user_and_habit_membership=membership
    ).last()
    membership.total_streak += 1

    # If user did the habit for the first time
    if not last_log:
        membership.max_streak += 1
        membership.curr_streak += 1

    # If user performing habit does not break the streak
    elif check_streak(completion_date, last_log.completion_date, curr_habit.periodicity):
        membership.curr_streak += 1

        # If the current streak is the largest streak ever
        if membership.curr_streak > membership.max_streak:
            membership.max_streak = membership.curr_streak
    # If user broke the streak
    else:
        membership.curr_streak = 1

    # Update the logs
    membership_logs = models.Logs(
        completion_date=completion_date, user_and_habit_membership=membership
    )
    membership_logs.save()
    membership.save()
    # Return serialised response
    result= http.JsonResponse(serialize_mem(membership))
    return result


# Analytics Functions

def get_user_info(request):
    """Returns a list of serialised user's habit information.
    :param request: HttpRequest object
    """
    # Get the data
    request_data = request.POST
    curr_user = models.User.objects.get(id=request_data["user_id"])
    curr_habits = list(models.UserAndHabitMembership.objects.filter(user=curr_user))

    # Returns a list of serialised user's habit information
    curr_habits = [serialize_mem(habit) for habit in curr_habits]
    result= http.JsonResponse(curr_habits, safe=False)
    return result


def get_habit_score(request):
    """Returns all habit scores based on how many users are linked to it.
    :param request: HttpRequest object
    """
    # Get data
    request_data = request.POST
    curr_habit = models.Habit.objects.get(id=request_data["habit_id"])
    # Get memberships ordered by total streak in ascending order
    memberships = models.UserAndHabitMembership.objects.filter(
        habit=curr_habit
    ).order_by("-total_streak")

    memberships = [
        serialize_user(membership)
        for membership in memberships
    ]
    result= http.JsonResponse(
        {"habit_name": curr_habit.habit_name, "score": memberships}
    )
    return result
