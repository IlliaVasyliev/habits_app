# A command-line utility that lets user interaction with Django project.
import sys
import os


def main():
    # Set Environment
    setting_path='habits_app.settings'
    os.environ.setdefault('DJANGO_SETTINGS_MODULE',setting_path )
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django."
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
