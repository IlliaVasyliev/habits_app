from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('habits/', include('habits.urlpatterns')),
    path('admin/', admin.site.urls),
]