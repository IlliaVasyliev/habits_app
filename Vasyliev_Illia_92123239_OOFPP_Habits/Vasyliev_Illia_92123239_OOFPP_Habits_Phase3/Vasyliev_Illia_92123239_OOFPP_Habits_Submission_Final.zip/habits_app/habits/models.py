from datetime import datetime
from django.db.models import Model as base_model
from django.db import models


# Create your models here.


class User(base_model):
    """User Model

    Attributes:
        username:     Identifier for the user
    """
    username = models.CharField(max_length=20, default='username')


class Habit(base_model):
    """Habit Model

    Attributes:
        habit_name:     Short description/title of the habit
        periodicity:    Ideal occurrence (periodicity) of the habit
        users:      Users linked to the habit
    """

    habit_name = models.CharField(max_length=50)
    periodicity = models.CharField(max_length=10, default='DAY')
    users = models.ManyToManyField(User, through='UserAndHabitMembership')


class UserAndHabitMembership(base_model):
    """User and Habit Membership model

    Attributes:
        user:     Foreign key to User Model
        habit:    Foreign key to Habit Model
        date_created:      Date when membership was created
        max_streak:      Longest Streak of the Habit by the user
        total_streak:      Total Streak of the Habit by the user
        curr_streak:      Current Streak of the Habit by the user
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE)
    date_created = models.DateField(default=datetime.now)
    max_streak = models.IntegerField(default=0)
    total_streak = models.IntegerField(default=0)
    curr_streak = models.IntegerField(default=0)


class Logs(base_model):
    """Logs Model

    Attributes:
        completion_date:     Date
        user_and_habit_membership:    Foreign Key to User Habit Membership
    """
    completion_date = models.DateField()
    user_and_habit_membership = models.ForeignKey(
        UserAndHabitMembership, on_delete=models.CASCADE)
