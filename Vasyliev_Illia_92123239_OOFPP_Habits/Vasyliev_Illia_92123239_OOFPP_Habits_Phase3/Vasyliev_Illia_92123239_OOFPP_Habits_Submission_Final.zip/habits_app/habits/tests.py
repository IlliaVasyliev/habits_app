# Import Libraries
from django.test import TestCase, Client
from .mock_data import fixtures

client = Client()


class HabitTests(TestCase):

    def test_all_logic(self):
        """Compares all actions with their ideal results."""

        # Habit Creation
        response = self.client.post(
            '/habits/create_habit', {'habit_name': 'running', 'periodicity': 'DAY'})
        self.assertEqual(response.json(), {'habit_id': 1})
        print('Habit Creation Done')


        # User Creation
        response = self.client.post(
            '/habits/create_user', {'username': 'Ilya'})
        self.assertEqual(response.json(), {'user_id': 1})
        print('User Creation Done')


        # User Habit Registration
        response = self.client.post(
            '/habits/add_user_for_habit', {'user_id': 1, 'habit_id': 1})
        self.assertEqual(response.json(), {'reg_habit_id': 1})
        print('Add Habit to User Done')

        # Habit done once
        response = self.client.post(
            '/habits/perform_habit', {'user_id': 1, 'habit_id': 1, 'completion_date': '2022-10-20'})
        self.assertEqual(response.json(), {
            'habit_name': 'running', 'total_streak': 1, 'max_streak': 1, 'curr_streak': 1})
        print('Checking off by user done')

        # Habit done again at the next day
        response = self.client.post(
            '/habits/perform_habit', {'user_id': 1, 'habit_id': 1, 'completion_date': '2022-10-21'})
        self.assertEqual(response.json(), {
            'habit_name': 'running', 'total_streak': 2, 'max_streak': 2, 'curr_streak': 2})
        print('Checking off by user done')

        # Habit done again at the next month
        response = self.client.post(
            '/habits/perform_habit', {'user_id': 1, 'habit_id': 1, 'completion_date': '2022-11-21'})
        self.assertEqual(response.json(), {
            'habit_name': 'running', 'total_streak': 3, 'max_streak': 2, 'curr_streak': 1})
        print('Checking off by user done')


        # Retrieve User Info
        response = self.client.post('/habits/get_user_info', {'user_id': 1})
        self.assertEqual(response.json(), [
            {'habit_name': 'running', 'total_streak': 3, 'max_streak': 2, 'curr_streak': 1}])
        print('get_user Done')

        # Habit score
        response = self.client.post(
            '/habits/get_habit_score', {'habit_id': 1})
        self.assertEqual(response.json(), {'habit_name': 'running', 'score': [
            {'user_id': 1, 'username': 'Ilya', 'total_streak': 3}]})
        print('get_habit_score Done')

        # Inserting Fixtures to database
        for data in fixtures:
            response = self.client.post(
                data['urlpath'], data['request'])
            self.assertEqual(response.json(), data['response'])
        print("Fixture Testing Completed")
