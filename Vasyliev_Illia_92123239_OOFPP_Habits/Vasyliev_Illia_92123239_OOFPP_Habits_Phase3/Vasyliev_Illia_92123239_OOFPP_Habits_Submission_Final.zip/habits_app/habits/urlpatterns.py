from venv import create
from django.urls import path
from . import django_views

urlpatterns = [
    # Entity Creation
    path('create_habit', django_views.create_habit, name='create_habit'),
    path('create_user', django_views.create_user, name='create_user'),
    

    # Habits Actions
    path('perform_habit', django_views.perform_habit, name='perform_habit'),
    path('add_user_for_habit', django_views.add_user_for_habit, name='add_user_for_habit'),
    

    # Analytics
    path('get_habit_score', django_views.get_habit_score, name='get_habit_score'),
    path('get_user_info', django_views.get_user_info, name='get_user_info')
    
]
